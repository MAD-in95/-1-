// ============================================================
// КЛИКЕР ПОДЗЕМЕЛЬЯ — основная логика
// ============================================================

// ---------- Звук (синтез через Web Audio API, без внешних файлов) ----------
const SFX = (() => {
  let ctx = null;
  let masterGain = null;
  let masterVolume = 0.85;
  function getCtx() {
    if (!ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      ctx = new AC();
      masterGain = ctx.createGain();
      masterGain.gain.value = masterVolume;
      masterGain.connect(ctx.destination);
    }
    if (ctx.state === 'suspended') ctx.resume();
    return ctx;
  }

  function noiseBuffer(c, duration) {
    const bufferSize = Math.floor(c.sampleRate * duration);
    const buffer = c.createBuffer(1, bufferSize, c.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) data[i] = Math.random() * 2 - 1;
    return buffer;
  }

  function hit() {
    const c = getCtx();
    const t0 = c.currentTime;
    const osc = c.createOscillator();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(180, t0);
    osc.frequency.exponentialRampToValueAtTime(60, t0 + 0.09);
    const gain = c.createGain();
    gain.gain.setValueAtTime(0.22, t0);
    gain.gain.exponentialRampToValueAtTime(0.001, t0 + 0.11);
    osc.connect(gain).connect(masterGain);
    osc.start(t0);
    osc.stop(t0 + 0.12);

    const noise = c.createBufferSource();
    noise.buffer = noiseBuffer(c, 0.06);
    const noiseFilter = c.createBiquadFilter();
    noiseFilter.type = 'bandpass';
    noiseFilter.frequency.value = 1200;
    const noiseGain = c.createGain();
    noiseGain.gain.setValueAtTime(0.15, t0);
    noiseGain.gain.exponentialRampToValueAtTime(0.001, t0 + 0.06);
    noise.connect(noiseFilter).connect(noiseGain).connect(masterGain);
    noise.start(t0);
    noise.stop(t0 + 0.06);
  }

  function hurt() {
    const c = getCtx();
    const t0 = c.currentTime;
    const osc = c.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(140, t0);
    osc.frequency.exponentialRampToValueAtTime(70, t0 + 0.15);
    const gain = c.createGain();
    gain.gain.setValueAtTime(0.16, t0);
    gain.gain.exponentialRampToValueAtTime(0.001, t0 + 0.17);
    osc.connect(gain).connect(masterGain);
    osc.start(t0);
    osc.stop(t0 + 0.18);
  }

  function kill() {
    const c = getCtx();
    const t0 = c.currentTime;
    const osc = c.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(300, t0);
    osc.frequency.exponentialRampToValueAtTime(40, t0 + 0.28);
    const gain = c.createGain();
    gain.gain.setValueAtTime(0.18, t0);
    gain.gain.exponentialRampToValueAtTime(0.001, t0 + 0.3);
    const filter = c.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(2000, t0);
    filter.frequency.exponentialRampToValueAtTime(200, t0 + 0.28);
    osc.connect(filter).connect(gain).connect(masterGain);
    osc.start(t0);
    osc.stop(t0 + 0.3);

    const noise = c.createBufferSource();
    noise.buffer = noiseBuffer(c, 0.25);
    const noiseGain = c.createGain();
    noiseGain.gain.setValueAtTime(0.12, t0);
    noiseGain.gain.exponentialRampToValueAtTime(0.001, t0 + 0.25);
    const noiseFilter = c.createBiquadFilter();
    noiseFilter.type = 'highpass';
    noiseFilter.frequency.value = 800;
    noise.connect(noiseFilter).connect(noiseGain).connect(masterGain);
    noise.start(t0);
    noise.stop(t0 + 0.25);
  }

  function gold() {
    const c = getCtx();
    const t0 = c.currentTime;
    [1600, 2400].forEach((freq, i) => {
      const osc = c.createOscillator();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, t0 + i * 0.03);
      const gain = c.createGain();
      gain.gain.setValueAtTime(0.001, t0 + i * 0.03);
      gain.gain.linearRampToValueAtTime(0.12, t0 + i * 0.03 + 0.01);
      gain.gain.exponentialRampToValueAtTime(0.001, t0 + i * 0.03 + 0.18);
      osc.connect(gain).connect(masterGain);
      osc.start(t0 + i * 0.03);
      osc.stop(t0 + i * 0.03 + 0.2);
    });
  }

  function upgrade() {
    const c = getCtx();
    const t0 = c.currentTime;
    [261.6, 329.6, 392.0, 523.3].forEach((freq, i) => {
      const osc = c.createOscillator();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, t0 + i * 0.05);
      const gain = c.createGain();
      gain.gain.setValueAtTime(0.001, t0 + i * 0.05);
      gain.gain.linearRampToValueAtTime(0.15, t0 + i * 0.05 + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, t0 + i * 0.05 + 0.35);
      osc.connect(gain).connect(masterGain);
      osc.start(t0 + i * 0.05);
      osc.stop(t0 + i * 0.05 + 0.4);
    });
  }

  function evolve() {
    const c = getCtx();
    const t0 = c.currentTime;
    [220, 277.2, 329.6, 440, 554.4].forEach((freq, i) => {
      const osc = c.createOscillator();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, t0 + i * 0.06);
      const gain = c.createGain();
      gain.gain.setValueAtTime(0.001, t0 + i * 0.06);
      gain.gain.linearRampToValueAtTime(0.16, t0 + i * 0.06 + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, t0 + i * 0.06 + 0.5);
      osc.connect(gain).connect(masterGain);
      osc.start(t0 + i * 0.06);
      osc.stop(t0 + i * 0.06 + 0.55);
    });
  }

  function unlock() {
    const c = getCtx();
    const t0 = c.currentTime;
    const osc = c.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(220, t0);
    const gain = c.createGain();
    gain.gain.setValueAtTime(0.001, t0);
    gain.gain.linearRampToValueAtTime(0.2, t0 + 0.05);
    gain.gain.exponentialRampToValueAtTime(0.001, t0 + 1.1);
    osc.connect(gain).connect(masterGain);
    osc.start(t0);
    osc.stop(t0 + 1.1);

    const osc2 = c.createOscillator();
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(330, t0);
    const gain2 = c.createGain();
    gain2.gain.setValueAtTime(0.001, t0);
    gain2.gain.linearRampToValueAtTime(0.1, t0 + 0.05);
    gain2.gain.exponentialRampToValueAtTime(0.001, t0 + 0.8);
    osc2.connect(gain2).connect(masterGain);
    osc2.start(t0);
    osc2.stop(t0 + 0.8);
  }

  function victory() {
    const c = getCtx();
    const t0 = c.currentTime;
    [392, 493.9, 587.3, 784].forEach((freq, i) => {
      const osc = c.createOscillator();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, t0 + i * 0.12);
      const gain = c.createGain();
      gain.gain.setValueAtTime(0.001, t0 + i * 0.12);
      gain.gain.linearRampToValueAtTime(0.18, t0 + i * 0.12 + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.001, t0 + i * 0.12 + 0.6);
      osc.connect(gain).connect(masterGain);
      osc.start(t0 + i * 0.12);
      osc.stop(t0 + i * 0.12 + 0.65);
    });
  }

  let muted = false;

  function setVolume(value) {
    masterVolume = Math.max(0, Math.min(1, Number(value)));
    if (masterGain) masterGain.gain.value = muted ? 0 : masterVolume;
  }

  function setMuted(value) {
    muted = Boolean(value);
    if (masterGain) masterGain.gain.value = muted ? 0 : masterVolume;
  }

  return { hit, hurt, kill, gold, upgrade, evolve, unlock, victory, unlockCtx: getCtx, setVolume, setMuted };
})();

// ---------- Данные: локации ----------
const LOCATIONS = [
  { id: 'fire',   name: 'Огненная бездна',      nameEn: 'Fire Abyss',       bg: 'assets/loc_fire.jpg',   enemyIds: ['lizard','gargoyle','lavawolf'] },
  { id: 'ice',    name: 'Ледяные руины',        nameEn: 'Frozen Ruins',      bg: 'assets/loc_ice.jpg',    enemyIds: ['icegolem','icereaper'] },
  { id: 'forest', name: 'Забытая роща',         nameEn: 'Forgotten Grove',   bg: 'assets/loc_forest.jpg', enemyIds: ['forestgolem','spider','treant'] },
  { id: 'swamp',  name: 'Гиблые топи',          nameEn: 'Dread Marshes',     bg: 'assets/loc_swamp.jpg',  enemyIds: ['spider','swamptroll'] },
  { id: 'rune',   name: 'Рунное святилище',     nameEn: 'Rune Sanctuary',    bg: 'assets/loc_rune.jpg',   enemyIds: ['gargoyle','assassin'] },
];

// Сколько врагов нужно зачистить на локации: 5, 6, 7, 8, 9...
function enemiesPerLocation(locationIndex) {
  return 5 + locationIndex;
}

// ---------- Данные: враги (общий пул для всех локаций) ----------
const ENEMIES = [
  { id: 'lizard',      name: 'Ящер-воин',        sprite: 'assets/enemy_lizard.png',      hpMul: 1.0,  goldMul: 1.0,  dmgMul: 1.0  },
  { id: 'gargoyle',    name: 'Каменный горгул',   sprite: 'assets/enemy_gargoyle.png',    hpMul: 1.3,  goldMul: 1.2,  dmgMul: 1.15 },
  { id: 'lavawolf',    name: 'Лавовый волк',      sprite: 'assets/enemy_lavawolf.png',    hpMul: 1.15, goldMul: 1.1,  dmgMul: 1.1  },
  { id: 'icegolem',    name: 'Ледяной голем',     sprite: 'assets/enemy_icegolem.png',    hpMul: 1.8,  goldMul: 1.6,  dmgMul: 1.3  },
  { id: 'icereaper',   name: 'Ледяной жнец',      sprite: 'assets/enemy_icereaper.png',   hpMul: 1.5,  goldMul: 1.4,  dmgMul: 1.25 },
  { id: 'forestgolem', name: 'Лесной страж',      sprite: 'assets/enemy_forestgolem.png', hpMul: 2.1,  goldMul: 1.8,  dmgMul: 1.4  },
  { id: 'spider',      name: 'Ядовитый паук',     sprite: 'assets/enemy_spider.png',      hpMul: 1.6,  goldMul: 1.5,  dmgMul: 1.35 },
  { id: 'treant',      name: 'Терновый древень',  sprite: 'assets/enemy_treant.png',      hpMul: 2.4,  goldMul: 2.0,  dmgMul: 1.5  },
  { id: 'swamptroll',  name: 'Болотный тролль',   sprite: 'assets/enemy_swamptroll.png',  hpMul: 2.7,  goldMul: 2.2,  dmgMul: 1.55 },
  { id: 'assassin',    name: 'Теневой убийца',    sprite: 'assets/enemy_assassin.png',    hpMul: 2.2,  goldMul: 2.4,  dmgMul: 1.6 },
];

// ---------- Данные: прогрессия героя (визуальные стадии, привязаны к эволюции) ----------
const HERO_STAGES = [
  { minEvolution: 0, sprite: 'assets/hero_01.png' },
  { minEvolution: 1, sprite: 'assets/hero_02.png' },
  { minEvolution: 2, sprite: 'assets/hero_03.png' },
  { minEvolution: 3, sprite: 'assets/hero_04.png' },
  { minEvolution: 4, sprite: 'assets/hero_05.png' },
  { minEvolution: 5, sprite: 'assets/hero_06.png' },
  { minEvolution: 6, sprite: 'assets/hero_07.png' },
  { minEvolution: 7, sprite: 'assets/hero_08.png' },
  { minEvolution: 8, sprite: 'assets/hero_09.png' },
  { minEvolution: 9, sprite: 'assets/hero_10.png' },
];

// ---------- Баланс апгрейдов ----------
const UPGRADE_BASE_COST = 6;
const UPGRADE_COST_GROWTH = 1.12;
const UPGRADE_DAMAGE_PER_LEVEL = 1;

const EVOLUTION_BASE_COST = 120;
const EVOLUTION_COST_GROWTH = 1.65;
// Множители эволюции: x1.2, x1.5, x1.8, x2.1 ...
const EVOLUTION_MULT_START = 1.2;
const EVOLUTION_MULT_STEP = 0.3;

const AUTOCLICK_BASE_COST = 30;
const AUTOCLICK_COST_GROWTH = 1.4;
const AUTOCLICK_INTERVAL_MS = 1000; // авто-удар раз в секунду
const AUTOCLICK_DAMAGE_BASE_FRACTION = 0.5; // на 1 уровне автоклик бьёт за 50% от клика

const DEFENSE_BASE_COST = 45;
const DEFENSE_COST_GROWTH = 1.3;
const DEFENSE_REDUCTION_PER_LEVEL = 0.06; // -6% входящего урона за уровень, с насыщением

// Урон врага по герою и шанс промаха
const ENEMY_MISS_CHANCE = 0.35; // 35% шанс что враг промахнётся
const ENEMY_BASE_DAMAGE = 4;
const HERO_BASE_MAX_HP = 50;
const HERO_HP_PER_UPGRADE_LEVEL = 4; // с апгрейдом урона герой чуть выносливее тоже

// ---------- Состояние игры ----------
const state = {
  gold: 0,
  clickDamage: 1,
  upgradeLevel: 1,

  evolutionLevel: 0, // 0 = не куплено
  evolutionMultiplier: 1,

  autoclickLevel: 0, // 0 = не куплено
  autoclickTimer: null,

  defenseLevel: 0,
  defenseReduction: 0,

  heroMaxHp: HERO_BASE_MAX_HP,
  heroHp: HERO_BASE_MAX_HP,

  totalKills: 0,
  currentLocationIndex: 0,
  enemiesKilledInLocation: 0,

  enemy: {
    defIndex: 0,
    hp: 0,
    maxHp: 0,
    goldReward: 0,
    damage: 0,
  },

  isPaused: false, // true во время victory-screen / паузы
  enemyTransitioning: false, // true в короткий промежуток между смертью врага и спавном нового
};

// ---------- Утилиты ----------
function formatNumber(n) {
  n = Math.floor(n);
  if (n < 1000) return String(n);
  if (n < 1_000_000) return (n / 1000).toFixed(n % 1000 === 0 ? 0 : 1) + 'K';
  if (n < 1_000_000_000) return (n / 1_000_000).toFixed(2) + 'M';
  return (n / 1_000_000_000).toFixed(2) + 'B';
}

function upgradeCost(level) {
  return Math.floor(UPGRADE_BASE_COST * Math.pow(UPGRADE_COST_GROWTH, level - 1));
}

// Прирост урона за один апгрейд, зависящий от текущей "декады" уровня:
// уровни 1-9 → +1, 10-19 → +2, 20-29 → +3, 30-39 → +4 и т.д.
function damagePerUpgradeAtLevel(level) {
  const decade = Math.floor(level / 10);
  return UPGRADE_DAMAGE_PER_LEVEL + decade;
}

function evolutionCost(level) {
  return Math.floor(EVOLUTION_BASE_COST * Math.pow(EVOLUTION_COST_GROWTH, level));
}

function evolutionMultiplierAtLevel(level) {
  // level 0 -> x1, level 1 -> x1.2, level 2 -> x1.5, level 3 -> x1.8 ...
  if (level <= 0) return 1;
  return EVOLUTION_MULT_START + (level - 1) * EVOLUTION_MULT_STEP;
}

function autoclickCost(level) {
  return Math.floor(AUTOCLICK_BASE_COST * Math.pow(AUTOCLICK_COST_GROWTH, level));
}

function defenseCost(level) {
  return Math.floor(DEFENSE_BASE_COST * Math.pow(DEFENSE_COST_GROWTH, level));
}

function defenseReductionAtLevel(level) {
  // Насыщающаяся защита: приближается к 70% снижения, никогда не даёт полную неуязвимость
  const raw = 1 - Math.pow(1 - DEFENSE_REDUCTION_PER_LEVEL, level);
  return Math.min(raw, 0.7);
}

function getEffectiveClickDamage() {
  return Math.max(1, Math.round(state.clickDamage * state.evolutionMultiplier));
}

function getAutoclickDamage() {
  if (state.autoclickLevel <= 0) return 0;
  const fraction = AUTOCLICK_DAMAGE_BASE_FRACTION + (state.autoclickLevel - 1) * 0.15;
  return Math.max(1, Math.round(getEffectiveClickDamage() * fraction));
}

function getHeroSprite() {
  let sprite = HERO_STAGES[0].sprite;
  for (const stage of HERO_STAGES) {
    if (state.evolutionLevel >= stage.minEvolution) sprite = stage.sprite;
  }
  return sprite;
}

function getHeroStageIndex() {
  let idx = 0;
  for (let i = 0; i < HERO_STAGES.length; i++) {
    if (state.evolutionLevel >= HERO_STAGES[i].minEvolution) idx = i;
  }
  return idx;
}

// Сложность врага растёт мягко с суммарным числом убийств
function enemyDifficultyMultiplier() {
  return Math.pow(1.11, state.totalKills);
}

// ---------- DOM-элементы ----------
const el = {
  loadingScreen: document.getElementById('loading-screen'),
  loadingBar: document.getElementById('loading-bar'),
  loadingPct: document.getElementById('loading-pct'),
  game: document.getElementById('game'),
  locationBg: document.getElementById('location-bg'),
  goldAmount: document.getElementById('gold-amount'),
  locationName: document.getElementById('location-name'),
  locationProgressBar: document.getElementById('location-progress-bar'),
  locationProgressText: document.getElementById('location-progress-text'),
  clickDamageLabel: document.getElementById('click-damage-label'),

  enemyWrap: document.getElementById('enemy-wrap'),
  enemyName: document.getElementById('enemy-name'),
  enemyHpBar: document.getElementById('enemy-hp-bar'),
  enemyHpText: document.getElementById('enemy-hp-text'),
  enemySprite: document.getElementById('enemy-sprite'),
  hitFxLayer: document.getElementById('hit-fx-layer'),

  heroWrap: document.getElementById('hero-wrap'),
  heroSprite: document.getElementById('hero-sprite'),
  heroLevelBadge: document.getElementById('hero-level-badge'),
  heroHpBar: document.getElementById('hero-hp-bar'),
  heroHpText: document.getElementById('hero-hp-text'),
  heroHitFxLayer: document.getElementById('hero-hit-fx-layer'),

  upgradeBtn: document.getElementById('upgrade-btn'),
  upgradeCostAmount: document.getElementById('upgrade-cost-amount'),
  upgradeLabelText: document.getElementById('upgrade-label-text'),

  autoclickBtn: document.getElementById('autoclick-btn'),
  autoclickCost: document.getElementById('autoclick-cost'),
  autoclickLevelEl: document.getElementById('autoclick-level'),
  autoclickLabelText: document.getElementById('autoclick-label'),

  evolutionBtn: document.getElementById('evolution-btn'),
  evolutionCost: document.getElementById('evolution-cost'),
  evolutionLevelEl: document.getElementById('evolution-level'),
  evolutionLabelText: document.getElementById('evolution-label-text'),

  defenseBtn: document.getElementById('defense-btn'),
  defenseCost: document.getElementById('defense-cost'),
  defenseLevelEl: document.getElementById('defense-level'),
  defenseLabelText: document.getElementById('defense-label-text'),

  unlockToast: document.getElementById('unlock-toast'),
  unlockToastName: document.getElementById('unlock-toast-name'),
  unlockToastTitle: document.getElementById('unlock-toast-title'),
  levelupToast: document.getElementById('levelup-toast'),
  levelupToastTitle: document.getElementById('levelup-toast-title'),

  victoryScreen: document.getElementById('victory-screen'),
  victoryTitle: document.getElementById('victory-title'),
  victoryLocationName: document.getElementById('victory-location-name'),
  victoryNextName: document.getElementById('victory-next-name'),
  victoryContinueBtn: document.getElementById('victory-continue-btn'),

  defeatScreen: document.getElementById('defeat-screen'),
  defeatTitle: document.getElementById('defeat-title'),
  defeatLocationName: document.getElementById('defeat-location-name'),
  defeatSub: document.getElementById('defeat-sub'),
  defeatRestartBtn: document.getElementById('defeat-restart-btn'),

  pauseBtn: document.getElementById('pause-btn'),
  pauseScreen: document.getElementById('pause-screen'),
  resumeBtn: document.getElementById('resume-btn'),
  soundVolume: document.getElementById('sound-volume'),
  soundValue: document.getElementById('sound-value'),
  effectsVolume: document.getElementById('effects-volume'),
  langRuBtn: document.getElementById('lang-ru-btn'),
  langEnBtn: document.getElementById('lang-en-btn'),
  locationCards: document.getElementById('location-cards'),
  pauseTitle: document.getElementById('pause-title'),
  pauseSoundLabel: document.getElementById('pause-sound-label'),
  pauseEffectsLabel: document.getElementById('pause-effects-label'),
  pauseLanguageLabel: document.getElementById('pause-language-label'),

  tutorialScreen: document.getElementById('tutorial-screen'),
  tutorialTitle: document.getElementById('tutorial-title'),
  tutorialHitText: document.getElementById('tutorial-hit-text'),
  tutorialUpgradeText: document.getElementById('tutorial-upgrade-text'),
  tutorialPauseText: document.getElementById('tutorial-pause-text'),
  tutorialOkBtn: document.getElementById('tutorial-ok-btn'),
};

// ---------- Спавн врага ----------
function spawnEnemy() {
  const loc = LOCATIONS[state.currentLocationIndex];
  const pool = loc.enemyIds || ENEMIES.map(e => e.id);
  const enemyId = pool[Math.floor(Math.random() * pool.length)];
  const defIndex = ENEMIES.findIndex(e => e.id === enemyId);
  const def = ENEMIES[defIndex];
  const diff = enemyDifficultyMultiplier();
  const maxHp = Math.max(1, Math.floor(5 * def.hpMul * diff));
  const goldReward = Math.max(1, Math.floor(2 * def.goldMul * diff));
  const damage = Math.max(1, Math.round(ENEMY_BASE_DAMAGE * def.dmgMul * Math.pow(1.045, state.totalKills)));

  state.enemy.defIndex = defIndex;
  state.enemy.hp = maxHp;
  state.enemy.maxHp = maxHp;
  state.enemy.goldReward = goldReward;
  state.enemy.damage = damage;

  el.enemySprite.src = def.sprite;
  el.enemySprite.classList.remove('faces-right');
  el.enemySprite.style.removeProperty('--face');
  el.enemyName.textContent = getEnemyDisplayName(def);
  el.enemyWrap.classList.remove('dying');
  updateEnemyHpBar();
}

function updateEnemyHpBar() {
  const pct = Math.max(0, (state.enemy.hp / state.enemy.maxHp) * 100);
  el.enemyHpBar.style.width = pct + '%';
  el.enemyHpText.textContent = `${formatNumber(Math.max(0, state.enemy.hp))} / ${formatNumber(state.enemy.maxHp)}`;
}

function updateHeroHpBar() {
  const pct = Math.max(0, (state.heroHp / state.heroMaxHp) * 100);
  el.heroHpBar.style.width = pct + '%';
  el.heroHpText.textContent = `${Math.ceil(Math.max(0, state.heroHp))} / ${state.heroMaxHp}`;
}

const I18N = {
  ru: {
    damage: 'Урон', enemy: 'Враг', pause: 'ПАУЗА', continue: 'ПРОДОЛЖИТЬ', stop: 'СТОП', start: 'СТАРТ', sound: 'ЗВУК', effects: 'ЭФФЕКТЫ', language: 'ЯЗЫК', russian: 'Русский', english: 'English', newLocation: 'Новая локация открыта!', cleared: 'Локация зачищена!', next: 'Следующая локация', goNext: 'Идти дальше', heroFell: 'Герой пал...', heroFellSub: 'Волна врагов слишком сильна. Собери силы и попробуй снова.', restart: 'Начать волну заново', autoLocations: 'Автосмена локаций', tutorialTitle: 'БЫСТРОЕ ОБУЧЕНИЕ', tutorialHit: 'Кликай по монстру мышкой или нажимай ПРОБЕЛ, чтобы атаковать.', tutorialUpgrade: 'За золото покупай улучшения и увеличивай урон.', tutorialPause: 'В паузе можно настроить звук и язык.', tutorialOk: 'ПОНЯТНО', upgradeLabelDamage: 'Урон', upgradeLabelAutoclick: 'Автоудар', upgradeLabelEvolution: 'Эволюция', upgradeLabelDefense: 'Защита', heroLevelShort: 'Ур.', levelUp: 'Герой стал сильнее!'
  },
  en: {
    damage: 'Damage', enemy: 'Enemy', pause: 'PAUSE', continue: 'CONTINUE', stop: 'STOP', start: 'START', sound: 'SOUND', effects: 'EFFECTS', language: 'LANGUAGE', russian: 'Русский', english: 'English', newLocation: 'New location unlocked!', cleared: 'Location cleared!', next: 'Next location', goNext: 'Continue', heroFell: 'Hero has fallen...', heroFellSub: 'The enemy wave was too strong. Gather your strength and try again.', restart: 'Restart wave', autoLocations: 'Auto location change', tutorialTitle: 'QUICK TUTORIAL', tutorialHit: 'Click the monster with the mouse or press SPACE to attack.', tutorialUpgrade: 'Spend gold on upgrades to increase your damage.', tutorialPause: 'Use pause to adjust sound and language.', tutorialOk: 'GOT IT', upgradeLabelDamage: 'Damage', upgradeLabelAutoclick: 'Auto-hit', upgradeLabelEvolution: 'Evolution', upgradeLabelDefense: 'Defense', heroLevelShort: 'Lvl', levelUp: 'The hero grows stronger!'
  }
};
let currentLang = 'ru';

function t(key) { return I18N[currentLang][key] || I18N.ru[key] || key; }
function getLocationDisplayName(loc) { return currentLang === 'en' ? loc.nameEn : loc.name; }
function getEnemyDisplayName(def) {
  const map = {
    'Ящер-воин': 'Lizard Warrior', 'Каменный горгул': 'Stone Gargoyle', 'Лавовый волк': 'Lava Wolf',
    'Ледяной голем': 'Ice Golem', 'Ледяной жнец': 'Ice Reaper', 'Лесной страж': 'Forest Guardian',
    'Ядовитый паук': 'Poison Spider', 'Терновый древень': 'Thorn Treant', 'Болотный тролль': 'Swamp Troll',
    'Теневой убийца': 'Shadow Assassin'
  };
  return currentLang === 'en' ? (map[def.name] || def.name) : def.name;
}

function applyLanguage(lang) {
  currentLang = lang === 'en' ? 'en' : 'ru';
  document.documentElement.lang = currentLang;
  el.locationName.textContent = currentLang === 'en' ? LOCATIONS[state.currentLocationIndex].nameEn : LOCATIONS[state.currentLocationIndex].name;
  el.clickDamageLabel.textContent = `${t('damage')}: ${formatNumber(getEffectiveClickDamage())}`;
  if (el.pauseTitle) el.pauseTitle.textContent = t('pause');
  if (el.resumeBtn) el.resumeBtn.textContent = t('continue');
  if (el.pauseSoundLabel) el.pauseSoundLabel.textContent = t('sound');
  if (el.pauseEffectsLabel) el.pauseEffectsLabel.textContent = t('effects');
  if (el.pauseLanguageLabel) el.pauseLanguageLabel.textContent = t('language');
  if (el.langRuBtn) el.langRuBtn.textContent = t('russian');
  if (el.langEnBtn) el.langEnBtn.textContent = t('english');
  if (el.upgradeLabelText) el.upgradeLabelText.textContent = t('upgradeLabelDamage');
  if (el.autoclickLabelText) el.autoclickLabelText.textContent = t('upgradeLabelAutoclick');
  if (el.evolutionLabelText) el.evolutionLabelText.textContent = t('upgradeLabelEvolution');
  if (el.defenseLabelText) el.defenseLabelText.textContent = t('upgradeLabelDefense');
  if (el.unlockToastTitle) el.unlockToastTitle.textContent = t('newLocation');
  if (el.levelupToastTitle) el.levelupToastTitle.textContent = t('levelUp');
  if (el.victoryTitle) el.victoryTitle.textContent = t('cleared');
  if (el.defeatTitle) el.defeatTitle.textContent = t('heroFell');
  if (el.defeatSub) el.defeatSub.textContent = t('heroFellSub');
  if (el.defeatRestartBtn) el.defeatRestartBtn.textContent = t('restart');
  updateTutorialLanguage();
  renderLocationCards();
  updateHud();
}

function renderLocationCards() {
  if (!el.locationCards) return;
  el.locationCards.innerHTML = '';
  LOCATIONS.forEach((loc, index) => {
    const card = document.createElement('button');
    card.className = 'location-card' + (index === state.currentLocationIndex ? ' active' : '');
    card.type = 'button';
    card.innerHTML = `<span class="location-card-index">${index + 1}</span><span>${currentLang === 'en' ? loc.nameEn : loc.name}</span>`;
    card.addEventListener('click', () => {
      if (state.isPaused) return;
      setLocation(index);
      spawnEnemy();
      state.enemyTransitioning = false;
      updateHud();
    });
    el.locationCards.appendChild(card);
  });
}

// ---------- Обновление всего HUD ----------
function updateHud() {
  el.goldAmount.textContent = formatNumber(state.gold);
  el.clickDamageLabel.textContent = `${t('damage')}: ${formatNumber(getEffectiveClickDamage())}`;

  const loc = LOCATIONS[state.currentLocationIndex];
  el.locationName.textContent = currentLang === 'en' ? loc.nameEn : loc.name;

  const needed = enemiesPerLocation(state.currentLocationIndex);
  el.locationProgressBar.style.width = Math.min(100, (state.enemiesKilledInLocation / needed) * 100) + '%';
  el.locationProgressText.textContent = `${t('enemy')} ${Math.min(state.enemiesKilledInLocation + 1, needed)} / ${needed}`;

  // Кнопка урона за клик
  const cost = upgradeCost(state.upgradeLevel);
  el.upgradeCostAmount.textContent = formatNumber(cost);
  el.upgradeBtn.classList.toggle('disabled', state.gold < cost);

  // Кнопка автоклика
  const acCost = autoclickCost(state.autoclickLevel);
  el.autoclickCost.textContent = formatNumber(acCost);
  el.autoclickLevelEl.textContent = state.autoclickLevel > 0 ? state.autoclickLevel : '';
  el.autoclickBtn.classList.toggle('disabled', state.gold < acCost);

  // Кнопка эволюции
  const evCost = evolutionCost(state.evolutionLevel);
  el.evolutionCost.textContent = formatNumber(evCost);
  el.evolutionLevelEl.textContent = state.evolutionLevel > 0 ? ('x' + state.evolutionMultiplier.toFixed(1)) : '';
  el.evolutionBtn.classList.toggle('disabled', state.gold < evCost);

  // Кнопка защиты
  const defCost = defenseCost(state.defenseLevel);
  el.defenseCost.textContent = formatNumber(defCost);
  el.defenseLevelEl.textContent = state.defenseLevel > 0 ? ('-' + Math.round(state.defenseReduction * 100) + '%') : '';
  el.defenseBtn.classList.toggle('disabled', state.gold < defCost);

  el.heroLevelBadge.textContent = `${t('heroLevelShort')} ${state.upgradeLevel}`;

  updateHeroHpBar();
}

function setLocation(index, { silent = false } = {}) {
  state.currentLocationIndex = index;
  state.enemiesKilledInLocation = 0;
  const loc = LOCATIONS[index];
  el.locationBg.style.backgroundImage = `url('${loc.bg}')`;
  if (!silent) {
    SFX.unlock();
    el.unlockToastName.textContent = currentLang === 'en' ? loc.nameEn : loc.name;
    el.unlockToast.classList.remove('hidden');
    el.unlockToast.style.animation = 'none';
    void el.unlockToast.offsetWidth;
    el.unlockToast.style.animation = '';
  }
  renderLocationCards();
}

function checkHeroLevelUp(prevStageIndex) {
  const newStageIndex = getHeroStageIndex();
  if (newStageIndex > prevStageIndex) {
    el.heroSprite.src = getHeroSprite();
    el.levelupToast.classList.remove('hidden');
    el.levelupToast.style.animation = 'none';
    void el.levelupToast.offsetWidth;
    el.levelupToast.style.animation = '';
  }
}

// ---------- Визуальные эффекты ----------
function spawnDamagePopup(amount, x, y, toHero = false) {
  const popup = document.createElement('div');
  popup.className = 'dmg-popup' + (toHero ? ' to-hero' : '');
  popup.textContent = '-' + formatNumber(amount);
  popup.style.left = x + 'px';
  popup.style.top = y + 'px';
  const layer = toHero ? el.heroHitFxLayer : el.hitFxLayer;
  layer.appendChild(popup);
  setTimeout(() => popup.remove(), 750);
}

function spawnGoldPopup(amount) {
  const rect = el.enemyWrap.getBoundingClientRect();
  const popup = document.createElement('div');
  popup.className = 'gold-popup';
  popup.textContent = '+' + formatNumber(amount) + ' ◆';
  popup.style.left = (rect.width / 2 - 20 + (Math.random() * 40 - 20)) + 'px';
  popup.style.top = (rect.height * 0.3) + 'px';
  popup.style.setProperty('--drift', (Math.random() * 40 - 20) + 'px');
  el.hitFxLayer.appendChild(popup);
  setTimeout(() => popup.remove(), 950);
}

function triggerHeroAttackAnim() {
  el.heroWrap.classList.remove('attack');
  void el.heroWrap.offsetWidth;
  el.heroWrap.classList.add('attack');
}

function triggerHeroHurtAnim() {
  el.heroWrap.classList.remove('hurt');
  void el.heroWrap.offsetWidth;
  el.heroWrap.classList.add('hurt');
}

function triggerEnemyHitAnim() {
  el.enemyWrap.classList.remove('hit');
  void el.enemyWrap.offsetWidth;
  el.enemyWrap.classList.add('hit');
}

// ---------- Враг атакует героя ----------
function enemyAttackHero() {
  if (state.isPaused) return;
  const missed = Math.random() < ENEMY_MISS_CHANCE;
  if (missed) return;

  const rawDmg = state.enemy.damage;
  const reducedDmg = Math.max(1, Math.round(rawDmg * (1 - state.defenseReduction)));
  state.heroHp = Math.max(0, state.heroHp - reducedDmg);

  SFX.hurt();
  triggerHeroHurtAnim();

  const rect = el.heroWrap.getBoundingClientRect();
  const x = rect.width / 2 + (Math.random() * 30 - 15);
  const y = rect.height * 0.25;
  spawnDamagePopup(reducedDmg, x, y, true);

  updateHeroHpBar();

  if (state.heroHp <= 0) {
    showDefeatScreen();
  }
}

// ---------- Основной клик по врагу ----------
function onEnemyClick(evt) {
  if (state.isPaused || state.enemyTransitioning) return;
  dealDamageToEnemy(getEffectiveClickDamage(), evt);
}

function dealDamageToEnemy(dmg, evt) {
  if (state.enemyTransitioning) return;
  state.enemy.hp -= dmg;

  SFX.hit();
  triggerHeroAttackAnim();
  triggerEnemyHitAnim();

  const rect = el.enemyWrap.getBoundingClientRect();
  let x, y;
  if (evt && (evt.clientX != null || (evt.touches && evt.touches[0]))) {
    const clientX = (evt.touches && evt.touches[0]) ? evt.touches[0].clientX : evt.clientX;
    const clientY = (evt.touches && evt.touches[0]) ? evt.touches[0].clientY : evt.clientY;
    x = (clientX - rect.left) + (Math.random() * 20 - 10);
    y = (clientY - rect.top);
  } else {
    x = rect.width / 2 + (Math.random() * 30 - 15);
    y = rect.height * 0.35;
  }
  spawnDamagePopup(dmg, x, y, false);

  if (state.enemy.hp <= 0) {
    killEnemy();
  } else {
    updateEnemyHpBar();
  }
}

function killEnemy() {
  state.enemyTransitioning = true;
  state.gold += state.enemy.goldReward;
  state.totalKills += 1;
  state.enemiesKilledInLocation += 1;

  // Восстановление здоровья героя после убийства — полностью
  state.heroHp = state.heroMaxHp;

  SFX.kill();
  SFX.gold();
  spawnGoldPopup(state.enemy.goldReward);
  el.enemyWrap.classList.add('dying');
  updateEnemyHpBar();

  const needed = enemiesPerLocation(state.currentLocationIndex);
  const locationCleared = state.enemiesKilledInLocation >= needed;

  updateHud();
  requestSave();

  if (locationCleared) {
    setTimeout(() => showVictoryScreen(), 380);
  } else {
    setTimeout(() => {
      spawnEnemy();
      state.enemyTransitioning = false;
    }, 320);
  }
}

function showVictoryScreen() {
  state.isPaused = true;
  SFX.victory();

  const loc = LOCATIONS[state.currentLocationIndex];
  const nextIndex = (state.currentLocationIndex + 1) % LOCATIONS.length;
  const nextLoc = LOCATIONS[nextIndex];

  el.victoryLocationName.textContent = getLocationDisplayName(loc);
  el.victoryNextName.innerHTML = `<span class="next-loc-label">${t('next')}</span>${getLocationDisplayName(nextLoc)}`;
  el.victoryContinueBtn.textContent = t('goNext');

  el.victoryScreen.classList.remove('hidden');
}

function onVictoryContinue() {
  el.victoryScreen.classList.add('hidden');
  state.isPaused = false;
  state.enemyTransitioning = false;

  const nextIndex = (state.currentLocationIndex + 1) % LOCATIONS.length;
  setLocation(nextIndex);
  updateHud();
  spawnEnemy();
  saveGameLocal();
  saveGameToYandexCloud();
}

// ---------- Поражение героя ----------
function showDefeatScreen() {
  state.isPaused = true;
  const loc = LOCATIONS[state.currentLocationIndex];
  el.defeatLocationName.textContent = getLocationDisplayName(loc);
  el.defeatScreen.classList.remove('hidden');
  saveGameLocal();
}

function onDefeatRestart() {
  el.defeatScreen.classList.add('hidden');
  state.isPaused = false;
  state.enemyTransitioning = false;

  // Откат волны на текущей локации, полное восстановление здоровья.
  // Золото, апгрейды и прогресс героя не теряются — только текущая волна начинается заново.
  state.enemiesKilledInLocation = 0;
  state.heroHp = state.heroMaxHp;
  updateHeroHpBar();
  updateHud();
  spawnEnemy();
  saveGameLocal();
}

// ---------- Апгрейд: урон за клик ----------
function onUpgradeClick() {
  if (state.isPaused) return;
  const cost = upgradeCost(state.upgradeLevel);
  if (state.gold < cost) return;

  SFX.upgrade();
  state.gold -= cost;
  state.upgradeLevel += 1;
  state.clickDamage += damagePerUpgradeAtLevel(state.upgradeLevel);
  state.heroMaxHp = HERO_BASE_MAX_HP + (state.upgradeLevel - 1) * HERO_HP_PER_UPGRADE_LEVEL;
  state.heroHp = Math.min(state.heroMaxHp, state.heroHp + HERO_HP_PER_UPGRADE_LEVEL);

  updateHud();
  requestSave();
}

// ---------- Апгрейд: эволюция (множитель урона + смена облика героя) ----------
function onEvolutionClick() {
  if (state.isPaused) return;
  const cost = evolutionCost(state.evolutionLevel);
  if (state.gold < cost) return;

  SFX.evolve();
  state.gold -= cost;
  const stageBefore = getHeroStageIndex();

  state.evolutionLevel += 1;
  state.evolutionMultiplier = evolutionMultiplierAtLevel(state.evolutionLevel);

  updateHud();
  checkHeroLevelUp(stageBefore);
  requestSave();
}

// ---------- Апгрейд: автоклик ----------
function onAutoclickClick() {
  if (state.isPaused) return;
  const cost = autoclickCost(state.autoclickLevel);
  if (state.gold < cost) return;

  SFX.upgrade();
  state.gold -= cost;
  state.autoclickLevel += 1;

  ensureAutoclickTimer();
  updateHud();
  requestSave();
}

function ensureAutoclickTimer() {
  if (state.autoclickTimer) return;
  state.autoclickTimer = setInterval(() => {
    if (state.isPaused || state.enemyTransitioning) return;
    if (state.autoclickLevel <= 0) return;
    const dmg = getAutoclickDamage();
    if (dmg > 0) dealDamageToEnemy(dmg, null);
  }, AUTOCLICK_INTERVAL_MS);
}

// ---------- Апгрейд: защита ----------
function onDefenseClick() {
  if (state.isPaused) return;
  const cost = defenseCost(state.defenseLevel);
  if (state.gold < cost) return;

  SFX.upgrade();
  state.gold -= cost;
  state.defenseLevel += 1;
  state.defenseReduction = defenseReductionAtLevel(state.defenseLevel);

  updateHud();
  requestSave();
}

// ---------- Периодическая атака врага по герою ----------
let enemyAttackTimer = null;
function startEnemyAttackLoop() {
  if (enemyAttackTimer) return;
  enemyAttackTimer = setInterval(() => {
    if (state.isPaused) return;
    enemyAttackHero();
  }, 1600);
}

function nextLocation() {
  const next = (state.currentLocationIndex + 1) % LOCATIONS.length;
  setLocation(next);
  state.enemyTransitioning = false;
  spawnEnemy();
  updateHud();
}

function openPause() {
  state.isPaused = true;
  el.pauseScreen.classList.remove('hidden');
}
function closePause() {
  el.pauseScreen.classList.add('hidden');
  state.isPaused = false;
}

function closeTutorial() {
  if (!el.tutorialScreen) return;
  el.tutorialScreen.classList.add('hidden');
  try { localStorage.setItem('dungeon_clicker_tutorial_seen', '1'); } catch (_) {}
}

function showTutorialIfNeeded() {
  if (!el.tutorialScreen) return;
  let seen = false;
  try { seen = localStorage.getItem('dungeon_clicker_tutorial_seen') === '1'; } catch (_) {}
  if (!seen) el.tutorialScreen.classList.remove('hidden');
}

function updateTutorialLanguage() {
  if (!el.tutorialScreen) return;
  if (el.tutorialTitle) el.tutorialTitle.textContent = t('tutorialTitle');
  if (el.tutorialHitText) el.tutorialHitText.textContent = t('tutorialHit');
  if (el.tutorialUpgradeText) el.tutorialUpgradeText.textContent = t('tutorialUpgrade');
  if (el.tutorialPauseText) el.tutorialPauseText.textContent = t('tutorialPause');
  if (el.tutorialOkBtn) el.tutorialOkBtn.textContent = t('tutorialOk');
}

// ---------- Yandex Games SDK ----------
let ysdk = null;
let yandexSdkLanguage = 'ru';
let yandexForcedPause = false;
let yandexPauseWasManual = false;

async function initYandexSDK() {
  // The game can still be opened locally, where /sdk.js is unavailable.
  if (typeof YaGames === 'undefined') return null;

  try {
    ysdk = await YaGames.init();

    const sdkLang = ysdk?.environment?.i18n?.lang || 'ru';
    yandexSdkLanguage = String(sdkLang).toLowerCase().startsWith('en') ? 'en' : 'ru';
    currentLang = yandexSdkLanguage;

    // Yandex can pause the game for fullscreen/rewarded ads and tab switching.
    ysdk.on?.('game_api_pause', onYandexPause);
    ysdk.on?.('game_api_resume', onYandexResume);

    return ysdk;
  } catch (error) {
    console.warn('Yandex Games SDK initialization failed:', error);
    ysdk = null;
    return null;
  }
}

function onYandexPause() {
  yandexForcedPause = true;
  yandexPauseWasManual = state.isPaused;
  state.isPaused = true;
  if (typeof SFX.setMuted === 'function') SFX.setMuted(true);
}

function onYandexResume() {
  if (!yandexForcedPause) return;
  yandexForcedPause = false;
  if (typeof SFX.setMuted === 'function') SFX.setMuted(false);
  // If the player had opened the game's own pause menu, keep it paused.
  state.isPaused = yandexPauseWasManual;
}

// Пауза при переключении вкладки/сворачивании окна — работает независимо от Yandex SDK,
// так что срабатывает и при локальном тестировании, и как страховка на платформе.
let tabHiddenForcedPause = false;
let tabHiddenPauseWasManual = false;
function onVisibilityChange() {
  if (document.hidden) {
    tabHiddenForcedPause = true;
    tabHiddenPauseWasManual = state.isPaused;
    state.isPaused = true;
    if (typeof SFX.setMuted === 'function') SFX.setMuted(true);
    saveGameLocal();
  } else {
    if (!tabHiddenForcedPause) return;
    tabHiddenForcedPause = false;
    if (typeof SFX.setMuted === 'function') SFX.setMuted(false);
    state.isPaused = tabHiddenPauseWasManual;
  }
}
document.addEventListener('visibilitychange', onVisibilityChange);

// Отключаем контекстное меню браузера (правый клик / долгий тап) внутри игры —
// требование платформы Yandex Games, чтобы игра ощущалась как приложение, а не веб-страница.
document.addEventListener('contextmenu', (e) => {
  if (e.target.closest && e.target.closest('#game')) e.preventDefault();
});

// Финальная попытка сохранить прогресс перед закрытием/уходом со страницы.
window.addEventListener('pagehide', () => { saveGameLocal(); });
window.addEventListener('beforeunload', () => { saveGameLocal(); });

async function markYandexGameReady() {
  if (!ysdk) return;
  try {
    ysdk.features?.LoadingAPI?.ready?.();
  } catch (error) {
    console.warn('Yandex Game Ready failed:', error);
  }
}

// ---------- Сохранение прогресса ----------
const SAVE_KEY = 'dungeon_clicker_save_v1';
const SAVE_FIELDS = [
  'gold', 'clickDamage', 'upgradeLevel',
  'evolutionLevel', 'evolutionMultiplier',
  'autoclickLevel',
  'defenseLevel', 'defenseReduction',
  'heroMaxHp', 'heroHp',
  'totalKills', 'currentLocationIndex', 'enemiesKilledInLocation',
];

function serializeState() {
  const data = {};
  for (const f of SAVE_FIELDS) data[f] = state[f];
  data.enemy = { ...state.enemy };
  data.savedAt = Date.now();
  return data;
}

function saveGameLocal() {
  try {
    localStorage.setItem(SAVE_KEY, JSON.stringify(serializeState()));
  } catch (_) { /* localStorage может быть недоступен (приватный режим и т.п.) — не критично */ }
}

function loadGameLocal() {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch (_) {
    return null;
  }
}

function applySaveData(data) {
  if (!data || typeof data !== 'object') return false;
  for (const f of SAVE_FIELDS) {
    if (data[f] !== undefined) state[f] = data[f];
  }
  if (data.enemy) state.enemy = { ...state.enemy, ...data.enemy };
  // Защита от повреждённых/устаревших сохранений
  if (!Number.isFinite(state.currentLocationIndex) || state.currentLocationIndex < 0 || state.currentLocationIndex >= LOCATIONS.length) {
    state.currentLocationIndex = 0;
  }
  if (!Number.isFinite(state.heroMaxHp) || state.heroMaxHp <= 0) state.heroMaxHp = HERO_BASE_MAX_HP;
  if (!Number.isFinite(state.heroHp) || state.heroHp <= 0) state.heroHp = state.heroMaxHp;
  return true;
}

// Debounce, чтобы не писать в localStorage на каждый клик — раз в 2 секунды после последнего изменения.
let saveDebounceTimer = null;
function requestSave() {
  if (saveDebounceTimer) clearTimeout(saveDebounceTimer);
  saveDebounceTimer = setTimeout(() => {
    saveGameLocal();
    saveGameToYandexCloud();
  }, 2000);
}

async function saveGameToYandexCloud() {
  if (!ysdk) return;
  try {
    const player = await ysdk.getPlayer?.({ scopes: false });
    if (player?.setData) await player.setData(serializeState());
  } catch (_) { /* нет доступа/не авторизован — тихо игнорируем, localStorage остаётся источником истины */ }
}

async function loadGameFromYandexCloud() {
  if (!ysdk) return null;
  try {
    const player = await ysdk.getPlayer?.({ scopes: false });
    if (player?.getData) {
      const data = await player.getData();
      return (data && Object.keys(data).length) ? data : null;
    }
  } catch (_) { /* ignore */ }
  return null;
}

// ---------- Инициализация игры ----------
function initGame() {
  const unlockAudio = () => {
    SFX.unlockCtx();
    document.removeEventListener('pointerdown', unlockAudio);
  };
  document.addEventListener('pointerdown', unlockAudio);

  el.enemyWrap.addEventListener('click', onEnemyClick);
  el.enemyWrap.addEventListener('touchstart', function (e) {
    e.preventDefault();
    onEnemyClick(e);
  }, { passive: false });

  // Клик по врагу: мышь/тач + пробел. Повторное срабатывание при удержании пробела отключено.
  document.addEventListener('keydown', (e) => {
    if (e.code !== 'Space' || e.repeat) return;
    if (state.isPaused || state.enemyTransitioning) return;
    if (el.tutorialScreen && !el.tutorialScreen.classList.contains('hidden')) return;
    e.preventDefault();
    SFX.unlockCtx();
    dealDamageToEnemy(getEffectiveClickDamage());
  });

  el.upgradeBtn.addEventListener('click', onUpgradeClick);
  el.evolutionBtn.addEventListener('click', onEvolutionClick);
  el.autoclickBtn.addEventListener('click', onAutoclickClick);
  el.defenseBtn.addEventListener('click', onDefenseClick);
  el.victoryContinueBtn.addEventListener('click', onVictoryContinue);
  el.defeatRestartBtn.addEventListener('click', onDefeatRestart);
  el.pauseBtn.addEventListener('click', openPause);
  el.resumeBtn.addEventListener('click', closePause);
  el.soundVolume.addEventListener('input', (e) => { SFX.setVolume(e.target.value / 100); el.soundValue.textContent = e.target.value + '%'; if (el.effectsVolume) el.effectsVolume.value = e.target.value; });
  if (el.effectsVolume) el.effectsVolume.addEventListener('input', (e) => { SFX.setVolume(e.target.value / 100); if (el.soundVolume) el.soundVolume.value = e.target.value; if (el.soundValue) el.soundValue.textContent = e.target.value + '%'; });
  el.langRuBtn.addEventListener('click', () => applyLanguage('ru'));
  el.langEnBtn.addEventListener('click', () => applyLanguage('en'));
  if (el.tutorialOkBtn) el.tutorialOkBtn.addEventListener('click', closeTutorial);

  el.heroSprite.src = getHeroSprite();

  // Пытаемся восстановить прогресс: сначала быстрый localStorage, затем (тихо) облако Яндекса поверх, если оно новее.
  const localSave = loadGameLocal();
  let restored = applySaveData(localSave);

  if (restored) {
    setLocation(state.currentLocationIndex, { silent: true });
    el.heroSprite.src = getHeroSprite();
    // Если сохранённый враг ещё жив — продолжаем бой с ним, иначе спавним нового.
    const enemyDef = ENEMIES[state.enemy.defIndex];
    if (enemyDef && state.enemy.hp > 0 && state.enemy.maxHp > 0) {
      el.enemySprite.src = enemyDef.sprite;
      el.enemySprite.classList.remove('faces-right');
      el.enemySprite.style.removeProperty('--face');
      el.enemyName.textContent = getEnemyDisplayName(enemyDef);
      el.enemyWrap.classList.remove('dying');
      updateEnemyHpBar();
    } else {
      spawnEnemy();
    }
  } else {
    setLocation(0, { silent: true });
    spawnEnemy();
  }

  updateHud();
  startEnemyAttackLoop();
  renderLocationCards();
  applyLanguage(yandexSdkLanguage);
  if (!restored) showTutorialIfNeeded();

  // Облачное сохранение Яндекса может быть новее локального (например, игрок зашёл с другого устройства).
  loadGameFromYandexCloud().then((cloudData) => {
    if (!cloudData) return;
    const cloudTime = cloudData.savedAt || 0;
    const localTime = localSave?.savedAt || 0;
    if (cloudTime > localTime) {
      applySaveData(cloudData);
      setLocation(state.currentLocationIndex, { silent: true });
      el.heroSprite.src = getHeroSprite();
      spawnEnemy();
      updateHud();
    }
  });
}

// ============================================================
// Загрузка ассетов с прогресс-баром
// ============================================================
const ALL_ASSETS = [
  ...LOCATIONS.map(l => l.bg),
  ...ENEMIES.map(e => e.sprite),
  ...HERO_STAGES.map(h => h.sprite),
];

function preloadAssets(assets, onProgress) {
  let loaded = 0;
  const total = assets.length;
  return Promise.all(assets.map(src => new Promise((resolve) => {
    const img = new Image();
    img.onload = img.onerror = () => {
      loaded++;
      onProgress(loaded / total);
      resolve();
    };
    img.src = src;
  })));
}

const yandexSdkPromise = initYandexSDK();

preloadAssets(ALL_ASSETS, (pct) => {
  const percent = Math.floor(pct * 100);
  el.loadingBar.style.width = percent + '%';
  el.loadingPct.textContent = percent + '%';
}).then(async () => {
  // Wait for SDK initialization too, so language detection happens at launch.
  await yandexSdkPromise;

  setTimeout(async () => {
    el.loadingScreen.classList.add('hidden');
    el.game.classList.remove('hidden');
    initGame();

    // Tell Yandex that all assets/UI are ready and the game can be played.
    await markYandexGameReady();
  }, 200);
});
